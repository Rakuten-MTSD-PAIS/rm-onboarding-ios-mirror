//
//  OneClick.h
//  OneClick
//
//  Created by Krishnan, Muthu on 25/07/23.
//

#import <Foundation/Foundation.h>

//! Project version number for OneClick.
FOUNDATION_EXPORT double OneClickVersionNumber;

//! Project version string for OneClick.
FOUNDATION_EXPORT const unsigned char OneClickVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OneClick/PublicHeader.h>


